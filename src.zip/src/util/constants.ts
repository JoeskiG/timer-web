export const CONSTANTS = {
    months: [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ]
}


export enum CONTROL_TYPES {
    number,
    options
}