import CountdownContainer from "../CountdownContainer"

function CountdownMenu(): JSX.Element {



    return (
        <div className="">
            <CountdownContainer />
        </div>
    )
}

export default CountdownMenu