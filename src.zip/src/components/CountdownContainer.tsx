import { useTimerContext } from "../contexts/useTimerContext"

function CountdownContainer(): JSX.Element {

    const { changeEndTimeFromString, isExpired, days, hours, minutes, seconds } = useTimerContext()

    return (
        <div className="flex flex-col">
            <div className="flex flex-row justify-between">
                <p>Countdown 1</p>
            </div>
            <div className='z-10 h-full w-full flex gap-8 flex-row items-center justify-center'>
                {
                    days > 0 && (
                        <>
                            <div className='p-4'>
                                <h1>{days} d</h1>
                            </div>
                            <p>:</p>
                        </>

                    )
                }

                {
                    hours >= 0 && (
                        <>
                            <div className='p-4'>
                                <h1>{hours} h</h1>
                            </div>
                            <p>:</p>
                        </>
                    )
                }

                {
                    minutes >= 0 && (
                        <>
                            <div className='p-4'>
                                <h1>{minutes} m</h1>
                            </div>
                            <p>:</p>
                        </>
                    )
                }

                {
                    seconds >= 0 && (
                        <>
                            <div className='p-4'>
                                <h1>{seconds} s</h1>
                            </div>
                        </>
                    )
                }

            </div>
        </div>
    )
}

export default CountdownContainer